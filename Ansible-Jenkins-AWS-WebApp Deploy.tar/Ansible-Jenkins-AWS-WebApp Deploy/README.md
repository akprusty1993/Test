# maven-CICD pipeline-AWS-Ansible

To unsderstand working of Ansible and create a playbook that is used to share application over SSH to the tomcat server for deployment. The playbook is triggered using Jenkins
